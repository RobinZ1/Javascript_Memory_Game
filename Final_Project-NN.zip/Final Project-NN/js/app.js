/*
 * 创建一个包含所有卡片的数组
 */
var icons = ["fa fa-diamond","fa fa-paper-plane-o", "fa fa-anchor",
  "fa fa-bolt", "fa fa-cube","fa fa-leaf","fa fa-bicycle","fa fa-bomb"];
//notice: 每个牌元素有两个icons， 以用来对应原牌与翻牌

icons = icons.concat(icons);


const cardsContainer = document.querySelector(".deck");

let openedCards = [];
let matchedCards = [];

const timeContainer = document.querySelector(".timer");
setInterval(function() {
    timeContainer.innerHTML++;
},1000);


//issue: double clicking the same card will make it visible, 
//I solved this issue by createing a class 'doubleC' in css file for this event
//refer to line 85-86

//----------------------整洁的分界线-----------------------
function init() {
//create the cards and adding them upto deck!-------------
    shuffle(icons); //uncommented this to start the game, otherwise, commented it for testing
    //no moves
    moves = 0;
    movesContainer.innerHTML = "零";
    for (let i = 0; i < icons.length; i ++) {

        const card = document.createElement("li");
        card.classList.add("card"); //a class called 'card' is created which consists of only cards (refer to the html file) 
        card.innerHTML = "<i class = '"+icons[i]+"'></i>"; //innerHTMl is supported by chrome while textContent is not
        cardsContainer.appendChild(card); //put cards onto deck

        click(card);
    }
}

// Card Click Event -eventListener------------------------

function click(card) {
    card.addEventListener("click", function() {
        //flipping and show icons, refer to css file, 'open' and 'show'
        
        const currentCard = this;
        const previousCard = openedCards[0];
        //openedCards array can mostly have 2 cards, it gets reset comparison is made
        
        //if one card is already flipped, comparison between two is made
        if (openedCards.length === 1 ) {

            card.classList.add("open","show","doubleC");
            openedCards.push(this); //add clicked-cards(this) to array
            
            compare(currentCard, previousCard);
        }

        else {
            
            currentCard.classList.add("open","show","doubleC"); //doubleC is crucial, otherwise double clikcing the same card will make it visible, which is undesirable
            openedCards.push(this); 
            
        }
        
    });
}

//implementation of comparison-function----------------------------------

function compare(currentCard, previousCard) {

    addMove();

    if(currentCard.innerHTML === previousCard.innerHTML) {
        //console.log("Matched! :>")
        
        //compare
        currentCard.classList.add("match"); 
        previousCard.classList.add("match");
        
        matchedCards.push(currentCard, previousCard);
        openedCards = [];

        //check game status
        isEnd();

    }

    else {
        //console.log("Doesn't match! :<")
        //
        setTimeout(function() {
            currentCard.classList.remove("open", "show","doubleC");
            previousCard.classList.remove("open","show","doubleC");
            openedCards = [];
        }, 369);  //369 is a good number,miluku 代表：弥勒佛

    }

}



//move-function--------------------------------
const movesContainer = document.querySelector(".moves");
let moves = 0;
function addMove() {
    moves++;      
    movesContainer.innerHTML = moves;
    //rating record
    rating();
}


//rating---------------------------------------
const starContainer = document.querySelector(".stars");
let starDigit = 0;
function rating() {
    if (moves <= 10) {
        starContainer.innerHTML = '<li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li>';
        starDigit = 3;
    }

    else if (moves <= 15) {
        starContainer.innerHTML = '<li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li>';
        starDigit = 2;
    }

    else {
        starContainer.innerHTML = '<li><i class="fa fa-star"></i></li>';
        starDigit = 1;
    }

}

//Checking whether the game is ended or not---------------
function isEnd() {
    if(matchedCards.length == icons.length) {
        let timeDigit = timeContainer.innerHTML;
        alert("Congrats! You spent "+timeDigit+" seconds and you reached "+starDigit+" stars in "+moves+" steps, you wanna play again? Click button below!");
        
        
        //Delete All cards
        cardsContainer.innerHTML = "";
        //Call 'init' to create new cards
        init();
        //reset container variables
        matchedCards = [];
        starContainer.innerHTML = '<li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li>';
        //openedCards will re-initialize itself
        shuffle(icons);
        timeDigit = 0;
        timeContainer.innerHTML = 0;
    }
}



//洗牌函数来自于 http://stackoverflow.com/a/2450976----
function shuffle(icons) {

    var currentIndex = icons.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = icons[currentIndex];
        icons[currentIndex] = icons[randomIndex];
        icons[randomIndex] = temporaryValue;
    }

    return icons;
}


//restart-button-------------------------------
const restartB = document.querySelector(".restart");
restartB.addEventListener("click", function() {
    //Delete All cards
    cardsContainer.innerHTML = "";
    //no moves
    moves = 0;
    movesContainer.innerHTML = "零";
    //Call 'init' to create new cards
    init();
    //reset container variables
    matchedCards = [];
    starContainer.innerHTML = '<li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li><li><i class="fa fa-star"></i></li>';
    //openedCards will re-initialize itself
    timeContainer.innerHTML = 0;
    shuffle(icons);

});



//start game for the first time-----------------
init();


/*
 * 显示页面上的卡片
 *   - 使用下面提供的 "shuffle" 方法对数组中的卡片进行洗牌
 *   - 循环遍历每张卡片，创建其 HTML
 *   - 将每张卡的 HTML 添加到页面
 */
/*

*/

